﻿namespace CustomerRecords
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.f2button1 = new System.Windows.Forms.Button();
            this.f2label1 = new System.Windows.Forms.Label();
            this.f2label2 = new System.Windows.Forms.Label();
            this.f2label3 = new System.Windows.Forms.Label();
            this.f2label4 = new System.Windows.Forms.Label();
            this.f2label5 = new System.Windows.Forms.Label();
            this.f2textBox1 = new System.Windows.Forms.TextBox();
            this.f2textBox2 = new System.Windows.Forms.TextBox();
            this.f2textBox3 = new System.Windows.Forms.TextBox();
            this.f2textBox4 = new System.Windows.Forms.TextBox();
            this.f2textBox5 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // f2button1
            // 
            this.f2button1.Font = new System.Drawing.Font("Verdana", 21F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.f2button1.Location = new System.Drawing.Point(16, 228);
            this.f2button1.Name = "f2button1";
            this.f2button1.Size = new System.Drawing.Size(531, 76);
            this.f2button1.TabIndex = 5;
            this.f2button1.Text = "Create Customer";
            this.f2button1.UseVisualStyleBackColor = true;
            this.f2button1.Click += new System.EventHandler(this.f2button1_Click);
            // 
            // f2label1
            // 
            this.f2label1.AutoSize = true;
            this.f2label1.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.f2label1.Location = new System.Drawing.Point(12, 34);
            this.f2label1.Name = "f2label1";
            this.f2label1.Size = new System.Drawing.Size(171, 23);
            this.f2label1.TabIndex = 1;
            this.f2label1.Text = "PhoneNumber:";
            // 
            // f2label2
            // 
            this.f2label2.AutoSize = true;
            this.f2label2.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.f2label2.Location = new System.Drawing.Point(12, 69);
            this.f2label2.Name = "f2label2";
            this.f2label2.Size = new System.Drawing.Size(128, 23);
            this.f2label2.TabIndex = 2;
            this.f2label2.Text = "FirstName:";
            // 
            // f2label3
            // 
            this.f2label3.AutoSize = true;
            this.f2label3.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.f2label3.Location = new System.Drawing.Point(12, 104);
            this.f2label3.Name = "f2label3";
            this.f2label3.Size = new System.Drawing.Size(125, 23);
            this.f2label3.TabIndex = 3;
            this.f2label3.Text = "LastName:";
            // 
            // f2label4
            // 
            this.f2label4.AutoSize = true;
            this.f2label4.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.f2label4.Location = new System.Drawing.Point(12, 139);
            this.f2label4.Name = "f2label4";
            this.f2label4.Size = new System.Drawing.Size(103, 23);
            this.f2label4.TabIndex = 4;
            this.f2label4.Text = "Address:";
            // 
            // f2label5
            // 
            this.f2label5.AutoSize = true;
            this.f2label5.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.f2label5.Location = new System.Drawing.Point(12, 176);
            this.f2label5.Name = "f2label5";
            this.f2label5.Size = new System.Drawing.Size(151, 23);
            this.f2label5.TabIndex = 5;
            this.f2label5.Text = "AccountDOB:";
            // 
            // f2textBox1
            // 
            this.f2textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.f2textBox1.Location = new System.Drawing.Point(225, 34);
            this.f2textBox1.MaxLength = 10;
            this.f2textBox1.Name = "f2textBox1";
            this.f2textBox1.Size = new System.Drawing.Size(236, 29);
            this.f2textBox1.TabIndex = 1;
            // 
            // f2textBox2
            // 
            this.f2textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.f2textBox2.Location = new System.Drawing.Point(225, 69);
            this.f2textBox2.Name = "f2textBox2";
            this.f2textBox2.Size = new System.Drawing.Size(236, 29);
            this.f2textBox2.TabIndex = 2;
            // 
            // f2textBox3
            // 
            this.f2textBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.f2textBox3.Location = new System.Drawing.Point(225, 104);
            this.f2textBox3.Name = "f2textBox3";
            this.f2textBox3.Size = new System.Drawing.Size(236, 29);
            this.f2textBox3.TabIndex = 3;
            // 
            // f2textBox4
            // 
            this.f2textBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.f2textBox4.Location = new System.Drawing.Point(225, 139);
            this.f2textBox4.Name = "f2textBox4";
            this.f2textBox4.Size = new System.Drawing.Size(236, 29);
            this.f2textBox4.TabIndex = 4;
            // 
            // f2textBox5
            // 
            this.f2textBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.f2textBox5.Location = new System.Drawing.Point(225, 176);
            this.f2textBox5.Name = "f2textBox5";
            this.f2textBox5.ReadOnly = true;
            this.f2textBox5.Size = new System.Drawing.Size(236, 29);
            this.f2textBox5.TabIndex = 1;
            this.f2textBox5.TabStop = false;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.ClientSize = new System.Drawing.Size(564, 320);
            this.Controls.Add(this.f2textBox5);
            this.Controls.Add(this.f2textBox4);
            this.Controls.Add(this.f2textBox3);
            this.Controls.Add(this.f2textBox2);
            this.Controls.Add(this.f2textBox1);
            this.Controls.Add(this.f2label5);
            this.Controls.Add(this.f2label4);
            this.Controls.Add(this.f2label3);
            this.Controls.Add(this.f2label2);
            this.Controls.Add(this.f2label1);
            this.Controls.Add(this.f2button1);
            this.Name = "Form2";
            this.Text = "Add New Customer";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button f2button1;
        private System.Windows.Forms.Label f2label1;
        private System.Windows.Forms.Label f2label2;
        private System.Windows.Forms.Label f2label3;
        private System.Windows.Forms.Label f2label4;
        private System.Windows.Forms.Label f2label5;
        private System.Windows.Forms.TextBox f2textBox1;
        private System.Windows.Forms.TextBox f2textBox2;
        private System.Windows.Forms.TextBox f2textBox3;
        private System.Windows.Forms.TextBox f2textBox4;
        private System.Windows.Forms.TextBox f2textBox5;
    }
}