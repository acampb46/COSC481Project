﻿namespace CustomerRecords
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.f3textBox1 = new System.Windows.Forms.TextBox();
            this.f3label1 = new System.Windows.Forms.Label();
            this.f3label2 = new System.Windows.Forms.Label();
            this.f3textBox3 = new System.Windows.Forms.TextBox();
            this.f3label3 = new System.Windows.Forms.Label();
            this.f3label4 = new System.Windows.Forms.Label();
            this.f3textBox5 = new System.Windows.Forms.TextBox();
            this.f3label5 = new System.Windows.Forms.Label();
            this.f3textBox6 = new System.Windows.Forms.TextBox();
            this.f3label6 = new System.Windows.Forms.Label();
            this.f3textBox7 = new System.Windows.Forms.TextBox();
            this.f3label7 = new System.Windows.Forms.Label();
            this.f3textBox8 = new System.Windows.Forms.TextBox();
            this.f3label8 = new System.Windows.Forms.Label();
            this.f3listBox1 = new System.Windows.Forms.ListBox();
            this.f3button1 = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // f3textBox1
            // 
            this.f3textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.f3textBox1.Location = new System.Drawing.Point(131, 47);
            this.f3textBox1.Name = "f3textBox1";
            this.f3textBox1.Size = new System.Drawing.Size(163, 29);
            this.f3textBox1.TabIndex = 2;
            // 
            // f3label1
            // 
            this.f3label1.AutoSize = true;
            this.f3label1.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.f3label1.Location = new System.Drawing.Point(12, 14);
            this.f3label1.Name = "f3label1";
            this.f3label1.Size = new System.Drawing.Size(80, 23);
            this.f3label1.TabIndex = 2;
            this.f3label1.Text = "Name:";
            // 
            // f3label2
            // 
            this.f3label2.AutoSize = true;
            this.f3label2.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.f3label2.Location = new System.Drawing.Point(300, 10);
            this.f3label2.Name = "f3label2";
            this.f3label2.Size = new System.Drawing.Size(112, 18);
            this.f3label2.TabIndex = 4;
            this.f3label2.Text = "Dog or Cat?";
            // 
            // f3textBox3
            // 
            this.f3textBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.f3textBox3.Location = new System.Drawing.Point(131, 7);
            this.f3textBox3.Name = "f3textBox3";
            this.f3textBox3.Size = new System.Drawing.Size(163, 29);
            this.f3textBox3.TabIndex = 1;
            // 
            // f3label3
            // 
            this.f3label3.AutoSize = true;
            this.f3label3.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.f3label3.Location = new System.Drawing.Point(299, 86);
            this.f3label3.Name = "f3label3";
            this.f3label3.Size = new System.Drawing.Size(87, 23);
            this.f3label3.TabIndex = 6;
            this.f3label3.Text = "Breed: ";
            // 
            // f3label4
            // 
            this.f3label4.AutoSize = true;
            this.f3label4.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.f3label4.Location = new System.Drawing.Point(12, 47);
            this.f3label4.Name = "f3label4";
            this.f3label4.Size = new System.Drawing.Size(74, 23);
            this.f3label4.TabIndex = 8;
            this.f3label4.Text = "Color:";
            // 
            // f3textBox5
            // 
            this.f3textBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.f3textBox5.Location = new System.Drawing.Point(131, 86);
            this.f3textBox5.Name = "f3textBox5";
            this.f3textBox5.Size = new System.Drawing.Size(163, 29);
            this.f3textBox5.TabIndex = 3;
            // 
            // f3label5
            // 
            this.f3label5.AutoSize = true;
            this.f3label5.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.f3label5.Location = new System.Drawing.Point(12, 166);
            this.f3label5.Name = "f3label5";
            this.f3label5.Size = new System.Drawing.Size(114, 23);
            this.f3label5.TabIndex = 10;
            this.f3label5.Text = "HairType:";
            // 
            // f3textBox6
            // 
            this.f3textBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.f3textBox6.Location = new System.Drawing.Point(131, 125);
            this.f3textBox6.Name = "f3textBox6";
            this.f3textBox6.Size = new System.Drawing.Size(163, 29);
            this.f3textBox6.TabIndex = 4;
            // 
            // f3label6
            // 
            this.f3label6.AutoSize = true;
            this.f3label6.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.f3label6.Location = new System.Drawing.Point(12, 86);
            this.f3label6.Name = "f3label6";
            this.f3label6.Size = new System.Drawing.Size(116, 23);
            this.f3label6.TabIndex = 12;
            this.f3label6.Text = "Markings:";
            // 
            // f3textBox7
            // 
            this.f3textBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.f3textBox7.Location = new System.Drawing.Point(131, 166);
            this.f3textBox7.Name = "f3textBox7";
            this.f3textBox7.Size = new System.Drawing.Size(163, 29);
            this.f3textBox7.TabIndex = 5;
            // 
            // f3label7
            // 
            this.f3label7.AutoSize = true;
            this.f3label7.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.f3label7.Location = new System.Drawing.Point(12, 131);
            this.f3label7.Name = "f3label7";
            this.f3label7.Size = new System.Drawing.Size(113, 23);
            this.f3label7.TabIndex = 14;
            this.f3label7.Text = "Allergies:";
            // 
            // f3textBox8
            // 
            this.f3textBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.f3textBox8.Location = new System.Drawing.Point(109, 211);
            this.f3textBox8.Multiline = true;
            this.f3textBox8.Name = "f3textBox8";
            this.f3textBox8.Size = new System.Drawing.Size(437, 111);
            this.f3textBox8.TabIndex = 6;
            // 
            // f3label8
            // 
            this.f3label8.AutoSize = true;
            this.f3label8.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.f3label8.Location = new System.Drawing.Point(12, 211);
            this.f3label8.Name = "f3label8";
            this.f3label8.Size = new System.Drawing.Size(80, 23);
            this.f3label8.TabIndex = 16;
            this.f3label8.Text = "Notes:";
            // 
            // f3listBox1
            // 
            this.f3listBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.f3listBox1.FormattingEnabled = true;
            this.f3listBox1.ItemHeight = 24;
            this.f3listBox1.Items.AddRange(new object[] {
            "Dog",
            "Cat"});
            this.f3listBox1.Location = new System.Drawing.Point(415, 7);
            this.f3listBox1.Name = "f3listBox1";
            this.f3listBox1.Size = new System.Drawing.Size(131, 52);
            this.f3listBox1.TabIndex = 7;
            // 
            // f3button1
            // 
            this.f3button1.Font = new System.Drawing.Font("Verdana", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.f3button1.Location = new System.Drawing.Point(12, 340);
            this.f3button1.Name = "f3button1";
            this.f3button1.Size = new System.Drawing.Size(534, 69);
            this.f3button1.TabIndex = 9;
            this.f3button1.Text = "Create Pet";
            this.f3button1.UseVisualStyleBackColor = true;
            this.f3button1.Click += new System.EventHandler(this.f3button1_Click);
            // 
            // listBox1
            // 
            this.listBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 24;
            this.listBox1.Items.AddRange(new object[] {
            "Large",
            "Medium",
            "Small"});
            this.listBox1.Location = new System.Drawing.Point(377, 86);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(169, 76);
            this.listBox1.TabIndex = 8;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.ClientSize = new System.Drawing.Size(558, 421);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.f3button1);
            this.Controls.Add(this.f3listBox1);
            this.Controls.Add(this.f3textBox8);
            this.Controls.Add(this.f3label8);
            this.Controls.Add(this.f3textBox7);
            this.Controls.Add(this.f3label7);
            this.Controls.Add(this.f3textBox6);
            this.Controls.Add(this.f3label6);
            this.Controls.Add(this.f3textBox5);
            this.Controls.Add(this.f3label5);
            this.Controls.Add(this.f3label4);
            this.Controls.Add(this.f3textBox3);
            this.Controls.Add(this.f3label3);
            this.Controls.Add(this.f3label2);
            this.Controls.Add(this.f3textBox1);
            this.Controls.Add(this.f3label1);
            this.Name = "Form3";
            this.Text = "Create Pet";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox f3textBox1;
        private System.Windows.Forms.Label f3label1;
        private System.Windows.Forms.Label f3label2;
        private System.Windows.Forms.TextBox f3textBox3;
        private System.Windows.Forms.Label f3label3;
        private System.Windows.Forms.Label f3label4;
        private System.Windows.Forms.TextBox f3textBox5;
        private System.Windows.Forms.Label f3label5;
        private System.Windows.Forms.TextBox f3textBox6;
        private System.Windows.Forms.Label f3label6;
        private System.Windows.Forms.TextBox f3textBox7;
        private System.Windows.Forms.Label f3label7;
        private System.Windows.Forms.TextBox f3textBox8;
        private System.Windows.Forms.Label f3label8;
        private System.Windows.Forms.ListBox f3listBox1;
        private System.Windows.Forms.Button f3button1;
        private System.Windows.Forms.ListBox listBox1;
    }
}